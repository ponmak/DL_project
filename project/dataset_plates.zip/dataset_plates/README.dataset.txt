# plates_new_dataset > 2025-02-25 11:35pm
https://universe.roboflow.com/projectdl-cjfj5/plates_new_dataset

Provided by a Roboflow user
License: CC BY 4.0

